<?php
	
	$users = array(
  array('id'=>1,
  'username'=> 'Jan',
  'email'=> 'fffff@wp.pl'),
  
  array('id'=>2,
   'username'=> 'Zenon',
   'email'=> 'ddddd@wp.pl'),
   
   array('id'=>3,
    'username'=> 'Jozef',
    'email'=> 'ccccc@wp.pl'),
   
     array('id'=>4,
    'username'=> 'Damian',
    'email'=> 'bbbbbbb@wp.pl'));
	// echo "<pre>";
	// var_dump($users);
	

	
?>